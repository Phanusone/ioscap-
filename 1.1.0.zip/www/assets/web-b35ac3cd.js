import{W as n}from"./index-ff5c71c7.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
