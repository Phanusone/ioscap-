import{X as n}from"./vendor.f0697659.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
