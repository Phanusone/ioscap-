import{W as n}from"./vendor.e2508ddc.js";class o extends n{async show(e){}async hide(e){}}export{o as SplashScreenWeb};
