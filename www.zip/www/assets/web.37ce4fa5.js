import{W as n}from"./vendor.a5f8b7d1.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
