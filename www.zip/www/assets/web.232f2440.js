import{W as n}from"./vendor.6742c370.js";class p extends n{async canOpenUrl(e){return{value:!0}}async openUrl(e){return window.open(e.url,"_blank"),{completed:!0}}}export{p as AppLauncherWeb};
