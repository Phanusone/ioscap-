import{W as n}from"./vendor.08a476dd.js";class o extends n{async show(e){}async hide(e){}}export{o as SplashScreenWeb};
